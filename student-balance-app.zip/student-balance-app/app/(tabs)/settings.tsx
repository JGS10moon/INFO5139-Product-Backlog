/**
 * Settings: notification toggle placeholder, Reset Demo Data (clear + re-seed).
 */

import { useState } from 'react';
import {
  ScrollView,
  StyleSheet,
  View,
  TouchableOpacity,
  Switch,
  Alert,
} from 'react-native';

import { Card } from '@/components/Card';
import { ThemedText } from '@/components/themed-text';
import { Colors } from '@/constants/theme';
import { resetDemoData } from '@/src/seedData';

export default function SettingsScreen() {
  const [notifications, setNotifications] = useState(true);
  const [resetting, setResetting] = useState(false);

  const handleReset = () => {
    Alert.alert(
      'Reset Demo Data',
      'This will clear all data and reload sample tasks, wellness entries, and goals. Continue?',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Reset',
          style: 'destructive',
          onPress: async () => {
            setResetting(true);
            try {
              await resetDemoData();
              Alert.alert('Done', 'Demo data has been reset.');
            } finally {
              setResetting(false);
            }
          },
        },
      ]
    );
  };

  return (
    <ScrollView
      style={styles.container}
      contentContainerStyle={styles.content}
      showsVerticalScrollIndicator={false}
    >
      <ThemedText type="subtitle" style={styles.sectionTitle}>
        Preferences
      </ThemedText>
      <Card>
        <View style={styles.row}>
          <ThemedText style={styles.rowLabel}>Notifications</ThemedText>
          <Switch
            value={notifications}
            onValueChange={setNotifications}
            trackColor={{ false: '#cbd5e1', true: Colors.light.tint }}
            thumbColor="#fff"
          />
        </View>
        <ThemedText style={styles.rowHint}>
          Placeholder — not wired to backend yet.
        </ThemedText>
      </Card>

      <ThemedText type="subtitle" style={styles.sectionTitle}>
        Data
      </ThemedText>
      <Card>
        <TouchableOpacity
          style={[styles.resetBtn, resetting && styles.resetBtnDisabled]}
          onPress={handleReset}
          disabled={resetting}
        >
          <ThemedText style={styles.resetBtnText}>
            {resetting ? 'Resetting…' : 'Reset Demo Data'}
          </ThemedText>
        </TouchableOpacity>
        <ThemedText style={styles.resetHint}>
          Clears AsyncStorage and re-seeds sample tasks, wellness entries, and goals.
        </ThemedText>
      </Card>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f0f2f5' },
  content: { padding: 16, paddingBottom: 32 },
  sectionTitle: {
    marginBottom: 8,
    marginLeft: 4,
    color: '#1a1a2e',
  },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  rowLabel: { fontSize: 16, fontWeight: '500' },
  rowHint: { marginTop: 8, fontSize: 13, opacity: 0.6 },
  resetBtn: {
    backgroundColor: '#e2e8f0',
    paddingVertical: 14,
    borderRadius: 12,
    alignItems: 'center',
  },
  resetBtnDisabled: { opacity: 0.6 },
  resetBtnText: { fontWeight: '600' },
  resetHint: { marginTop: 8, fontSize: 13, opacity: 0.7 },
});
