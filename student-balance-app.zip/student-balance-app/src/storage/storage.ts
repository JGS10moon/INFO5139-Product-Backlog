/**
 * AsyncStorage JSON helpers: get, set, clear.
 * No dependency on types or services to avoid circular imports.
 */

import AsyncStorage from '@react-native-async-storage/async-storage';

import { KEYS } from './keys';

export { KEYS };

export async function getStored<T>(key: string): Promise<T | null> {
  try {
    const raw = await AsyncStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : null;
  } catch {
    return null;
  }
}

export async function setStored(key: string, value: unknown): Promise<void> {
  await AsyncStorage.setItem(key, JSON.stringify(value));
}

export async function clearAppData(): Promise<void> {
  await AsyncStorage.multiRemove(Object.values(KEYS));
}
