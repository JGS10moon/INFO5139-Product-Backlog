/**
 * Wellness check-ins: add, list (last N).
 * Persisted via AsyncStorage; works offline.
 */

import { KEYS, getStored, setStored } from './storage';
import type { WellnessEntry } from '@/types';

export async function listWellnessEntries(limit?: number): Promise<WellnessEntry[]> {
  const entries = await getStored<WellnessEntry[]>(KEYS.WELLNESS);
  const list = entries ?? [];
  list.sort((a, b) => (b.createdAt > a.createdAt ? 1 : -1));
  return limit ? list.slice(0, limit) : list;
}

export async function addWellnessEntry(
  date: string,
  stressLevel: number,
  workloadLevel: number,
  note?: string
): Promise<WellnessEntry> {
  const entries = await getStored<WellnessEntry[]>(KEYS.WELLNESS);
  const list = entries ?? [];
  const entry: WellnessEntry = {
    id: `wellness_${Date.now()}_${Math.random().toString(36).slice(2, 9)}`,
    date,
    stressLevel,
    workloadLevel,
    note,
    createdAt: new Date().toISOString(),
  };
  list.push(entry);
  await setStored(KEYS.WELLNESS, list);
  return entry;
}

export async function setWellnessEntries(entries: WellnessEntry[]): Promise<void> {
  await setStored(KEYS.WELLNESS, entries);
}
