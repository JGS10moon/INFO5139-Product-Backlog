/**
 * Seed data for first run and "Reset Demo Data".
 * Ensures the app looks real on first launch and can be reset from Settings.
 */

import { KEYS, getStored, setStored, clearAppData } from './storage';
import type { Task, WellnessEntry, Goal } from '@/types';

const SAMPLE_TASKS: Task[] = [
  {
    id: 'task_seed_1',
    title: 'Read Ch. 5 – Biology',
    category: 'school',
    dueDate: new Date().toISOString().slice(0, 10),
    priority: 'high',
    completed: false,
    createdAt: new Date().toISOString(),
  },
  {
    id: 'task_seed_2',
    title: 'Math problem set 3',
    category: 'school',
    dueDate: new Date(Date.now() + 86400000).toISOString().slice(0, 10),
    priority: 'medium',
    completed: true,
    createdAt: new Date().toISOString(),
  },
  {
    id: 'task_seed_3',
    title: 'Grocery shopping',
    category: 'personal',
    dueDate: new Date().toISOString().slice(0, 10),
    priority: 'low',
    completed: false,
    createdAt: new Date().toISOString(),
  },
  {
    id: 'task_seed_4',
    title: '30 min walk',
    category: 'wellness',
    dueDate: new Date().toISOString().slice(0, 10),
    priority: 'medium',
    completed: false,
    createdAt: new Date().toISOString(),
  },
  {
    id: 'task_seed_5',
    title: 'Essay draft – History',
    category: 'school',
    dueDate: new Date(Date.now() + 2 * 86400000).toISOString().slice(0, 10),
    priority: 'high',
    completed: false,
    createdAt: new Date().toISOString(),
  },
];

const SAMPLE_WELLNESS: WellnessEntry[] = [
  {
    id: 'wellness_seed_1',
    date: new Date().toISOString().slice(0, 10),
    stressLevel: 3,
    workloadLevel: 4,
    note: 'Busy week, need to breathe.',
    createdAt: new Date().toISOString(),
  },
  {
    id: 'wellness_seed_2',
    date: new Date(Date.now() - 86400000).toISOString().slice(0, 10),
    stressLevel: 2,
    workloadLevel: 3,
    createdAt: new Date(Date.now() - 86400000).toISOString(),
  },
];

const SAMPLE_GOALS: Goal[] = [
  { id: 'goal_seed_1', title: 'Study sessions', targetPerWeek: 5, progressThisWeek: 3, createdAt: new Date().toISOString() },
  { id: 'goal_seed_2', title: 'Workouts', targetPerWeek: 3, progressThisWeek: 1, createdAt: new Date().toISOString() },
  { id: 'goal_seed_3', title: 'Sleep by 11pm', targetPerWeek: 7, progressThisWeek: 4, createdAt: new Date().toISOString() },
];

export async function isSeeded(): Promise<boolean> {
  const seeded = await getStored<string>(KEYS.SEEDED);
  return seeded === 'true';
}

export async function seedIfNeeded(): Promise<void> {
  if (await isSeeded()) return;
  await setStored(KEYS.TASKS, SAMPLE_TASKS);
  await setStored(KEYS.WELLNESS, SAMPLE_WELLNESS);
  await setStored(KEYS.GOALS, SAMPLE_GOALS);
  await setStored(KEYS.SEEDED, 'true');
}

/** Reset all app data and repopulate with seed data. Call from Settings. */
export async function resetDemoData(): Promise<void> {
  await clearAppData();
  await setStored(KEYS.TASKS, SAMPLE_TASKS);
  await setStored(KEYS.WELLNESS, SAMPLE_WELLNESS);
  await setStored(KEYS.GOALS, SAMPLE_GOALS);
  await setStored(KEYS.SEEDED, 'true');
}
