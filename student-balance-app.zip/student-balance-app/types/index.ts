/**
 * Shared types for tasks, wellness entries, and goals.
 */

export type TaskCategory = 'school' | 'personal' | 'wellness';

export type Priority = 'low' | 'medium' | 'high';

export interface Task {
  id: string;
  title: string;
  category: TaskCategory;
  dueDate: string; // ISO date YYYY-MM-DD
  priority: Priority;
  completed: boolean;
  createdAt: string; // ISO datetime
}

export interface WellnessEntry {
  id: string;
  date: string; // ISO date YYYY-MM-DD
  stressLevel: number; // 1-5
  workloadLevel: number; // 1-5
  note?: string;
  createdAt: string; // ISO datetime
}

export interface Goal {
  id: string;
  title: string;
  targetPerWeek: number; // e.g. 3 sessions per week
  progressThisWeek: number;
  createdAt: string;
}
