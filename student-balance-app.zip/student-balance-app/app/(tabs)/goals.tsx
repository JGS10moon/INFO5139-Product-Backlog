/**
 * Goals: list (title, target/week, progress), increment/decrement, add goal form.
 * Persisted via goalService.
 */

import { useFocusEffect } from 'expo-router';
import { useCallback, useState } from 'react';
import {
  ScrollView,
  StyleSheet,
  View,
  TouchableOpacity,
  TextInput,
  Modal,
  Pressable,
} from 'react-native';

import { Card } from '@/components/Card';
import { ThemedText } from '@/components/themed-text';
import { IconSymbol } from '@/components/ui/icon-symbol';
import { Colors } from '@/constants/theme';
import type { Goal } from '@/src/types';
import {
  listGoals,
  addGoal,
  incrementGoal,
  decrementGoal,
} from '@/src/services/goalService';

export default function GoalsScreen() {
  const [goals, setGoals] = useState<Goal[]>([]);
  const [modalVisible, setModalVisible] = useState(false);
  const [title, setTitle] = useState('');
  const [targetStr, setTargetStr] = useState('3');

  const load = useCallback(async () => {
    setGoals(await listGoals());
  }, []);

  useFocusEffect(
    useCallback(() => {
      load();
    }, [load])
  );

  const handleIncrement = useCallback(
    async (id: string) => {
      await incrementGoal(id);
      load();
    },
    [load]
  );

  const handleDecrement = useCallback(
    async (id: string) => {
      await decrementGoal(id);
      load();
    },
    [load]
  );

  const openAdd = useCallback(() => {
    setTitle('');
    setTargetStr('3');
    setModalVisible(true);
  }, []);

  const handleAdd = useCallback(async () => {
    const trimmed = title.trim();
    const target = parseInt(targetStr, 10);
    if (!trimmed || isNaN(target) || target < 1) return;
    await addGoal(trimmed, target);
    setModalVisible(false);
    load();
  }, [title, targetStr, load]);

  return (
    <View style={styles.container}>
      <ScrollView
        style={styles.scroll}
        contentContainerStyle={styles.content}
        showsVerticalScrollIndicator={false}
      >
        {goals.map((g) => (
          <Card key={g.id}>
            <View style={styles.goalRow}>
              <View style={styles.goalBody}>
                <ThemedText style={styles.goalTitle} numberOfLines={2}>
                  {g.title}
                </ThemedText>
                <ThemedText style={styles.meta}>
                  {g.progressThisWeek} / {g.targetPerWeek} per week
                </ThemedText>
              </View>
              <View style={styles.controls}>
                <TouchableOpacity
                  onPress={() => handleDecrement(g.id)}
                  style={styles.controlBtn}
                  disabled={g.progressThisWeek <= 0}
                >
                  <IconSymbol
                    name="minus.circle"
                    size={32}
                    color={
                      g.progressThisWeek <= 0 ? '#cbd5e1' : '#64748b'
                    }
                  />
                </TouchableOpacity>
                <TouchableOpacity
                  onPress={() => handleIncrement(g.id)}
                  style={styles.controlBtn}
                >
                  <IconSymbol
                    name="plus.circle.fill"
                    size={32}
                    color={Colors.light.tint}
                  />
                </TouchableOpacity>
              </View>
            </View>
          </Card>
        ))}
        {goals.length === 0 && (
          <Card>
            <ThemedText style={styles.empty}>
              No goals yet. Tap + to add one.
            </ThemedText>
          </Card>
        )}
      </ScrollView>

      <TouchableOpacity
        style={styles.fab}
        onPress={openAdd}
        activeOpacity={0.8}
      >
        <IconSymbol
          name="plus.circle.fill"
          size={56}
          color={Colors.light.tint}
        />
      </TouchableOpacity>

      <Modal visible={modalVisible} transparent animationType="slide">
        <Pressable
          style={styles.modalOverlay}
          onPress={() => setModalVisible(false)}
        >
          <Pressable
            style={styles.modalCard}
            onPress={(e) => e.stopPropagation()}
          >
            <ThemedText type="subtitle" style={styles.modalTitle}>
              New goal
            </ThemedText>

            <ThemedText style={styles.label}>Goal name</ThemedText>
            <TextInput
              style={styles.input}
              placeholder="e.g. Workouts"
              placeholderTextColor="#94a3b8"
              value={title}
              onChangeText={setTitle}
              autoCapitalize="sentences"
            />

            <ThemedText style={styles.label}>Target per week</ThemedText>
            <TextInput
              style={styles.input}
              placeholder="3"
              placeholderTextColor="#94a3b8"
              value={targetStr}
              onChangeText={setTargetStr}
              keyboardType="number-pad"
            />

            <View style={styles.modalActions}>
              <TouchableOpacity
                style={styles.cancelBtn}
                onPress={() => setModalVisible(false)}
              >
                <ThemedText>Cancel</ThemedText>
              </TouchableOpacity>
              <TouchableOpacity style={styles.addBtn} onPress={handleAdd}>
                <ThemedText style={styles.addBtnText}>Add</ThemedText>
              </TouchableOpacity>
            </View>
          </Pressable>
        </Pressable>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f0f2f5' },
  scroll: { flex: 1 },
  content: { padding: 16, paddingBottom: 88 },
  goalRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  goalBody: { flex: 1 },
  goalTitle: { fontSize: 17, fontWeight: '600' },
  meta: { fontSize: 14, opacity: 0.8, marginTop: 4 },
  controls: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  controlBtn: { padding: 4 },
  empty: { textAlign: 'center', opacity: 0.8 },
  fab: { position: 'absolute', right: 20, bottom: 24 },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.4)',
    justifyContent: 'flex-end',
  },
  modalCard: {
    backgroundColor: '#fff',
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    padding: 24,
    paddingBottom: 40,
  },
  modalTitle: { marginBottom: 16, color: '#1a1a2e' },
  label: { marginTop: 12, marginBottom: 6, fontSize: 14, fontWeight: '600' },
  input: {
    borderWidth: 1,
    borderColor: '#e2e8f0',
    borderRadius: 12,
    padding: 12,
    fontSize: 16,
    color: '#1a1a2e',
  },
  modalActions: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
    gap: 12,
    marginTop: 24,
  },
  cancelBtn: { padding: 12 },
  addBtn: {
    backgroundColor: Colors.light.tint,
    paddingHorizontal: 20,
    paddingVertical: 12,
    borderRadius: 12,
  },
  addBtnText: { color: '#fff', fontWeight: '600' },
});
