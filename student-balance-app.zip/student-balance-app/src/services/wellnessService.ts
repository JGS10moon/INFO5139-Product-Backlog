/**
 * Wellness entries: list, add, update. Stress/workload per entry. Persisted via AsyncStorage.
 * Helper: getEntryForDate(date) to prevent duplicate same-day check-ins (optional: update instead).
 */

import type { WellnessEntry } from '../types';
import { KEYS } from '../storage/keys';
import { getStored, setStored } from '../storage/storage';

export async function listWellness(limit?: number): Promise<WellnessEntry[]> {
  const entries = await getStored<WellnessEntry[]>(KEYS.WELLNESS);
  const list = entries ?? [];
  list.sort((a, b) => (b.createdAt > a.createdAt ? 1 : -1));
  return limit ? list.slice(0, limit) : list;
}

/** Returns existing entry for the given date (YYYY-MM-DD), or null. Use to prevent duplicate same-day check-in. */
export async function getEntryForDate(date: string): Promise<WellnessEntry | null> {
  const entries = await getStored<WellnessEntry[]>(KEYS.WELLNESS);
  const list = entries ?? [];
  return list.find((e) => e.date === date) ?? null;
}

export async function addWellness(
  date: string,
  stressLevel: number,
  workloadLevel: number,
  note?: string
): Promise<WellnessEntry> {
  const entries = await getStored<WellnessEntry[]>(KEYS.WELLNESS);
  const list = entries ?? [];
  const entry: WellnessEntry = {
    id: `wellness_${Date.now()}_${Math.random().toString(36).slice(2, 9)}`,
    date,
    stressLevel,
    workloadLevel,
    note,
    createdAt: new Date().toISOString(),
  };
  list.push(entry);
  await setStored(KEYS.WELLNESS, list);
  return entry;
}

/** Update an existing entry (e.g. same-day check-in). Keeps date and id. */
export async function updateWellness(
  id: string,
  stressLevel: number,
  workloadLevel: number,
  note?: string
): Promise<void> {
  const entries = await getStored<WellnessEntry[]>(KEYS.WELLNESS);
  const list = entries ?? [];
  const idx = list.findIndex((e) => e.id === id);
  if (idx === -1) return;
  list[idx].stressLevel = stressLevel;
  list[idx].workloadLevel = workloadLevel;
  list[idx].note = note;
  await setStored(KEYS.WELLNESS, list);
}
