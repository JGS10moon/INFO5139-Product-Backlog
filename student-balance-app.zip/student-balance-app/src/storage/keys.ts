/**
 * AsyncStorage keys for app data. Single place to change or clear keys.
 */

export const KEYS = {
  TASKS: '@student_balance/tasks',
  WELLNESS: '@student_balance/wellness',
  GOALS: '@student_balance/goals',
  SEEDED: '@student_balance/seeded',
} as const;
