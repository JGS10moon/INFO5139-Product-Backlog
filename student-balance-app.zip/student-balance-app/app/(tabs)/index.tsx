/**
 * Dashboard: unified weekly overview with School Tasks, Personal Goals, Wellness Activities.
 * Loads tasks, goals, wellness entries; shows counts and previews; rule-based suggestion cards.
 */

import { useFocusEffect } from 'expo-router';
import { useCallback, useState } from 'react';
import { ScrollView, StyleSheet, View } from 'react-native';

import { Card } from '@/components/Card';
import { ThemedText } from '@/components/themed-text';
import type { Task, Goal, WellnessEntry } from '@/src/types';
import { listTasks } from '@/src/services/taskService';
import { listGoals } from '@/src/services/goalService';
import { listWellness } from '@/src/services/wellnessService';

const PREVIEW_MAX = 5;
const STRESS_THRESHOLD = 4;
const DUE_SOON_DAYS = 3;

function formatDate(isoDate: string): string {
  return new Date(isoDate).toLocaleDateString(undefined, {
    weekday: 'short',
    month: 'short',
    day: 'numeric',
  });
}

function isDueSoon(dueDate: string): boolean {
  const due = new Date(dueDate);
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  due.setHours(0, 0, 0, 0);
  const diffDays = (due.getTime() - today.getTime()) / 86400000;
  return diffDays >= 0 && diffDays <= DUE_SOON_DAYS;
}

export default function DashboardScreen() {
  const [tasks, setTasks] = useState<Task[]>([]);
  const [goals, setGoals] = useState<Goal[]>([]);
  const [wellness, setWellness] = useState<WellnessEntry[]>([]);

  const load = useCallback(async () => {
    const [t, g, w] = await Promise.all([
      listTasks(),
      listGoals(),
      listWellness(7),
    ]);
    setTasks(t);
    setGoals(g);
    setWellness(w);
  }, []);

  useFocusEffect(
    useCallback(() => {
      load();
    }, [load])
  );

  const schoolTasks = tasks.filter((t) => t.category === 'school');
  const personalTasks = tasks.filter((t) => t.category === 'personal');
  const wellnessTasks = tasks.filter((t) => t.category === 'wellness');

  const stressAvg =
    wellness.length > 0
      ? wellness.reduce((s, e) => s + e.stressLevel, 0) / wellness.length
      : 0;
  const tasksDueSoon = tasks.filter(
    (t) => !t.completed && isDueSoon(t.dueDate)
  ).length;
  const showWellnessSuggestion = stressAvg >= STRESS_THRESHOLD;
  const showPlanningSuggestion = tasksDueSoon >= 3;

  return (
    <ScrollView
      style={styles.container}
      contentContainerStyle={styles.content}
      showsVerticalScrollIndicator={false}
    >
      {/* Rule-based suggestion cards */}
      {showWellnessSuggestion && (
        <Card style={styles.suggestionCard}>
          <ThemedText type="defaultSemiBold" style={styles.suggestionTitle}>
            Take a breath
          </ThemedText>
          <ThemedText style={styles.suggestionDesc}>
            Your recent check-ins show higher stress. Try a short walk or a wellness activity today.
          </ThemedText>
        </Card>
      )}
      {showPlanningSuggestion && (
        <Card style={styles.suggestionCard}>
          <ThemedText type="defaultSemiBold" style={styles.suggestionTitle}>
            Plan ahead
          </ThemedText>
          <ThemedText style={styles.suggestionDesc}>
            You have several tasks due soon. Review your Planner and prioritize.
          </ThemedText>
        </Card>
      )}

      {/* School Tasks */}
      <ThemedText type="subtitle" style={styles.sectionTitle}>
        School Tasks
      </ThemedText>
      <Card>
        <ThemedText style={styles.count}>
          {schoolTasks.length} task{schoolTasks.length !== 1 ? 's' : ''} this week
        </ThemedText>
        {schoolTasks.slice(0, PREVIEW_MAX).map((t) => (
          <View key={t.id} style={styles.previewRow}>
            <ThemedText
              style={[styles.previewTitle, t.completed && styles.completed]}
              numberOfLines={1}
            >
              {t.title}
            </ThemedText>
            <ThemedText style={styles.meta}>
              {formatDate(t.dueDate)} · {t.priority}
            </ThemedText>
          </View>
        ))}
        {schoolTasks.length === 0 && (
          <ThemedText style={styles.empty}>No school tasks yet.</ThemedText>
        )}
      </Card>

      {/* Personal Goals */}
      <ThemedText type="subtitle" style={styles.sectionTitle}>
        Personal Goals
      </ThemedText>
      <Card>
        <ThemedText style={styles.count}>
          {goals.length} goal{goals.length !== 1 ? 's' : ''} this week
        </ThemedText>
        {goals.slice(0, PREVIEW_MAX).map((g) => (
          <View key={g.id} style={styles.previewRow}>
            <ThemedText style={styles.previewTitle} numberOfLines={1}>
              {g.title}
            </ThemedText>
            <ThemedText style={styles.meta}>
              {g.progressThisWeek} / {g.targetPerWeek}
            </ThemedText>
          </View>
        ))}
        {goals.length === 0 && (
          <ThemedText style={styles.empty}>No goals yet. Add some in Goals.</ThemedText>
        )}
      </Card>

      {/* Wellness Activities */}
      <ThemedText type="subtitle" style={styles.sectionTitle}>
        Wellness Activities
      </ThemedText>
      <Card>
        <ThemedText style={styles.count}>
          {wellnessTasks.length} activit{wellnessTasks.length !== 1 ? 'ies' : 'y'} ·{' '}
          {wellness.length} check-in{wellness.length !== 1 ? 's' : ''} (last 7 days)
        </ThemedText>
        {wellnessTasks.slice(0, PREVIEW_MAX).map((t) => (
          <View key={t.id} style={styles.previewRow}>
            <ThemedText
              style={[styles.previewTitle, t.completed && styles.completed]}
              numberOfLines={1}
            >
              {t.title}
            </ThemedText>
            <ThemedText style={styles.meta}>{formatDate(t.dueDate)}</ThemedText>
          </View>
        ))}
        {wellnessTasks.length === 0 && (
          <ThemedText style={styles.empty}>No wellness activities yet.</ThemedText>
        )}
      </Card>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f0f2f5' },
  content: { padding: 16, paddingBottom: 32 },
  sectionTitle: {
    marginBottom: 8,
    marginLeft: 4,
    color: '#1a1a2e',
  },
  suggestionCard: {
    backgroundColor: '#e8f4f8',
    marginBottom: 16,
  },
  suggestionTitle: { marginBottom: 4, color: '#0a7ea4' },
  suggestionDesc: { fontSize: 14, lineHeight: 20, opacity: 0.9 },
  count: {
    fontSize: 14,
    opacity: 0.8,
    marginBottom: 12,
  },
  previewRow: { marginBottom: 10 },
  previewTitle: { fontSize: 16, fontWeight: '600' },
  completed: { textDecorationLine: 'line-through', opacity: 0.7 },
  meta: { fontSize: 13, opacity: 0.7, marginTop: 2 },
  empty: { fontSize: 14, opacity: 0.7, fontStyle: 'italic' },
});
