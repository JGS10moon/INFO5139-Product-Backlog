/**
 * Wellness: daily check-in (stress 1–5, workload 1–5, optional note).
 * Shows last 7 entries. Prevents duplicate same day; updates existing entry if present.
 */

import { useFocusEffect } from 'expo-router';
import { useCallback, useState } from 'react';
import {
  ScrollView,
  StyleSheet,
  View,
  TextInput,
  TouchableOpacity,
} from 'react-native';

import { Card } from '@/components/Card';
import { ThemedText } from '@/components/themed-text';
import type { WellnessEntry } from '@/src/types';
import {
  listWellness,
  getEntryForDate,
  addWellness,
  updateWellness,
} from '@/src/services/wellnessService';

function getTodayISO(): string {
  return new Date().toISOString().slice(0, 10);
}

function formatDate(isoDate: string): string {
  return new Date(isoDate).toLocaleDateString(undefined, {
    weekday: 'short',
    month: 'short',
    day: 'numeric',
  });
}

function notePreview(note: string | undefined, maxLen: number = 60): string {
  if (!note) return '';
  return note.length <= maxLen ? note : note.slice(0, maxLen) + '…';
}

export default function WellnessScreen() {
  const [entries, setEntries] = useState<WellnessEntry[]>([]);
  const [todayEntry, setTodayEntry] = useState<WellnessEntry | null>(null);
  const [stress, setStress] = useState(3);
  const [workload, setWorkload] = useState(3);
  const [note, setNote] = useState('');
  const [saving, setSaving] = useState(false);

  const load = useCallback(async () => {
    const today = getTodayISO();
    const [list, existing] = await Promise.all([
      listWellness(7),
      getEntryForDate(today),
    ]);
    setEntries(list);
    setTodayEntry(existing);
    if (existing) {
      setStress(existing.stressLevel);
      setWorkload(existing.workloadLevel);
      setNote(existing.note ?? '');
    }
  }, []);

  useFocusEffect(
    useCallback(() => {
      load();
    }, [load])
  );

  const handleSubmit = useCallback(async () => {
    if (saving) return;
    setSaving(true);
    const today = getTodayISO();
    try {
      if (todayEntry) {
        await updateWellness(
          todayEntry.id,
          stress,
          workload,
          note.trim() || undefined
        );
      } else {
        await addWellness(today, stress, workload, note.trim() || undefined);
      }
      setNote('');
      load();
    } finally {
      setSaving(false);
    }
  }, [stress, workload, note, todayEntry, load, saving]);

  return (
    <ScrollView
      style={styles.container}
      contentContainerStyle={styles.content}
      showsVerticalScrollIndicator={false}
    >
      <ThemedText type="subtitle" style={styles.sectionTitle}>
        Today's check-in
      </ThemedText>
      <Card>
        {todayEntry && (
          <ThemedText style={styles.updateHint}>
            You already checked in today. Update below if you’d like.
          </ThemedText>
        )}
        <ThemedText style={styles.label}>
          Stress (1 = low, 5 = high)
        </ThemedText>
        <View style={styles.scaleRow}>
          {[1, 2, 3, 4, 5].map((n) => (
            <TouchableOpacity
              key={n}
              style={[styles.scaleBtn, stress === n && styles.scaleBtnActive]}
              onPress={() => setStress(n)}
            >
              <ThemedText
                style={stress === n ? styles.scaleBtnTextActive : undefined}
              >
                {n}
              </ThemedText>
            </TouchableOpacity>
          ))}
        </View>
        <ThemedText style={styles.label}>
          Workload (1 = light, 5 = heavy)
        </ThemedText>
        <View style={styles.scaleRow}>
          {[1, 2, 3, 4, 5].map((n) => (
            <TouchableOpacity
              key={n}
              style={[styles.scaleBtn, workload === n && styles.scaleBtnActive]}
              onPress={() => setWorkload(n)}
            >
              <ThemedText
                style={workload === n ? styles.scaleBtnTextActive : undefined}
              >
                {n}
              </ThemedText>
            </TouchableOpacity>
          ))}
        </View>
        <ThemedText style={styles.label}>Note (optional)</ThemedText>
        <TextInput
          style={styles.noteInput}
          placeholder="How are you feeling?"
          placeholderTextColor="#94a3b8"
          value={note}
          onChangeText={setNote}
          multiline
          numberOfLines={2}
        />
        <TouchableOpacity
          style={[styles.submitBtn, saving && styles.submitBtnDisabled]}
          onPress={handleSubmit}
          disabled={saving}
        >
          <ThemedText style={styles.submitBtnText}>
            {saving
              ? 'Saving…'
              : todayEntry
                ? 'Update check-in'
                : 'Save check-in'}
          </ThemedText>
        </TouchableOpacity>
      </Card>

      <ThemedText type="subtitle" style={styles.sectionTitle}>
        Last 7 check-ins
      </ThemedText>
      {entries.map((e) => (
        <Card key={e.id}>
          <ThemedText style={styles.entryDate}>{formatDate(e.date)}</ThemedText>
          <View style={styles.entryRow}>
            <ThemedText style={styles.entryMeta}>
              Stress: {e.stressLevel}/5
            </ThemedText>
            <ThemedText style={styles.entryMeta}>
              Workload: {e.workloadLevel}/5
            </ThemedText>
          </View>
          {e.note ? (
            <ThemedText style={styles.entryNote} numberOfLines={2}>
              {notePreview(e.note)}
            </ThemedText>
          ) : null}
        </Card>
      ))}
      {entries.length === 0 && (
        <Card>
          <ThemedText style={styles.empty}>
            No check-ins yet. Add one above.
          </ThemedText>
        </Card>
      )}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f0f2f5' },
  content: { padding: 16, paddingBottom: 32 },
  sectionTitle: {
    marginBottom: 8,
    marginLeft: 4,
    color: '#1a1a2e',
  },
  updateHint: {
    fontSize: 13,
    opacity: 0.8,
    marginBottom: 12,
    fontStyle: 'italic',
  },
  label: { marginBottom: 8, fontSize: 14, fontWeight: '600' },
  scaleRow: { flexDirection: 'row', gap: 8, marginBottom: 16 },
  scaleBtn: {
    flex: 1,
    paddingVertical: 12,
    borderRadius: 12,
    backgroundColor: '#e2e8f0',
    alignItems: 'center',
  },
  scaleBtnActive: { backgroundColor: '#0a7ea4' },
  scaleBtnTextActive: { color: '#fff' },
  noteInput: {
    borderWidth: 1,
    borderColor: '#e2e8f0',
    borderRadius: 12,
    padding: 12,
    fontSize: 16,
    color: '#1a1a2e',
    minHeight: 72,
    textAlignVertical: 'top',
  },
  submitBtn: {
    marginTop: 16,
    backgroundColor: '#0a7ea4',
    paddingVertical: 14,
    borderRadius: 12,
    alignItems: 'center',
  },
  submitBtnDisabled: { opacity: 0.6 },
  submitBtnText: { color: '#fff', fontWeight: '600' },
  entryDate: { fontWeight: '600', marginBottom: 4 },
  entryRow: { flexDirection: 'row', gap: 16 },
  entryMeta: { fontSize: 14, opacity: 0.8 },
  entryNote: { marginTop: 8, fontSize: 14, fontStyle: 'italic', opacity: 0.9 },
  empty: { textAlign: 'center', opacity: 0.8 },
});
