/**
 * Thin AsyncStorage wrapper with JSON serialization.
 * All app data keys live here for a single place to reset.
 */

import AsyncStorage from '@react-native-async-storage/async-storage';

const KEYS = {
  TASKS: '@student_balance/tasks',
  WELLNESS: '@student_balance/wellness',
  GOALS: '@student_balance/goals',
  SEEDED: '@student_balance/seeded',
} as const;

export { KEYS };

export async function getStored<T>(key: string): Promise<T | null> {
  try {
    const raw = await AsyncStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : null;
  } catch {
    return null;
  }
}

export async function setStored(key: string, value: unknown): Promise<void> {
  await AsyncStorage.setItem(key, JSON.stringify(value));
}

export async function clearAppData(): Promise<void> {
  await AsyncStorage.multiRemove(Object.values(KEYS));
}
