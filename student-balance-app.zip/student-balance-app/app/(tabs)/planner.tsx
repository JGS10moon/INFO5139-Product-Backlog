/**
 * Planner: list all tasks (category, due date, priority, completed);
 * add task (modal); toggle complete. Persisted via taskService.
 */

import { useFocusEffect } from 'expo-router';
import { useCallback, useState } from 'react';
import {
  ScrollView,
  StyleSheet,
  View,
  TouchableOpacity,
  TextInput,
  Modal,
  Pressable,
} from 'react-native';

import { Card } from '@/components/Card';
import { ThemedText } from '@/components/themed-text';
import { IconSymbol } from '@/components/ui/icon-symbol';
import { Colors } from '@/constants/theme';
import type { Task, TaskCategory, Priority } from '@/src/types';
import {
  listTasks,
  addTask,
  toggleTaskComplete,
} from '@/src/services/taskService';

const CATEGORIES: { value: TaskCategory; label: string }[] = [
  { value: 'school', label: 'School' },
  { value: 'personal', label: 'Personal' },
  { value: 'wellness', label: 'Wellness' },
];

const PRIORITIES: { value: Priority; label: string }[] = [
  { value: 'low', label: 'Low' },
  { value: 'medium', label: 'Medium' },
  { value: 'high', label: 'High' },
];

function formatDate(isoDate: string): string {
  return new Date(isoDate).toLocaleDateString(undefined, {
    weekday: 'short',
    month: 'short',
    day: 'numeric',
  });
}

function getTodayISO(): string {
  return new Date().toISOString().slice(0, 10);
}

export default function PlannerScreen() {
  const [tasks, setTasks] = useState<Task[]>([]);
  const [modalVisible, setModalVisible] = useState(false);
  const [title, setTitle] = useState('');
  const [category, setCategory] = useState<TaskCategory>('school');
  const [dueDate, setDueDate] = useState(getTodayISO());
  const [priority, setPriority] = useState<Priority>('medium');

  const load = useCallback(async () => {
    setTasks(await listTasks());
  }, []);

  useFocusEffect(
    useCallback(() => {
      load();
    }, [load])
  );

  const handleToggle = useCallback(
    async (id: string) => {
      await toggleTaskComplete(id);
      load();
    },
    [load]
  );

  const openAdd = useCallback(() => {
    setTitle('');
    setCategory('school');
    setDueDate(getTodayISO());
    setPriority('medium');
    setModalVisible(true);
  }, []);

  const handleAdd = useCallback(async () => {
    const trimmed = title.trim();
    if (!trimmed) return;
    await addTask(trimmed, category, dueDate, priority);
    setModalVisible(false);
    load();
  }, [title, category, dueDate, priority, load]);

  const sortedTasks = [...tasks].sort(
    (a, b) => new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime()
  );

  return (
    <View style={styles.container}>
      <ScrollView
        style={styles.scroll}
        contentContainerStyle={styles.content}
        showsVerticalScrollIndicator={false}
      >
        {sortedTasks.map((t) => (
          <Card key={t.id}>
            <View style={styles.taskRow}>
              <TouchableOpacity
                onPress={() => handleToggle(t.id)}
                hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
                style={styles.checkWrap}
              >
                <IconSymbol
                  name={t.completed ? 'checkmark.circle.fill' : 'checkmark.circle'}
                  size={26}
                  color={t.completed ? '#22c55e' : '#94a3b8'}
                />
              </TouchableOpacity>
              <View style={styles.taskBody}>
                <ThemedText
                  style={[styles.taskTitle, t.completed && styles.completed]}
                  numberOfLines={2}
                >
                  {t.title}
                </ThemedText>
                <ThemedText style={styles.meta}>
                  {t.category} · {formatDate(t.dueDate)} · {t.priority}
                </ThemedText>
              </View>
            </View>
          </Card>
        ))}
        {tasks.length === 0 && (
          <Card>
            <ThemedText style={styles.empty}>
              No tasks yet. Tap + to add one.
            </ThemedText>
          </Card>
        )}
      </ScrollView>

      <TouchableOpacity
        style={styles.fab}
        onPress={openAdd}
        activeOpacity={0.8}
      >
        <IconSymbol
          name="plus.circle.fill"
          size={56}
          color={Colors.light.tint}
        />
      </TouchableOpacity>

      <Modal visible={modalVisible} transparent animationType="slide">
        <Pressable
          style={styles.modalOverlay}
          onPress={() => setModalVisible(false)}
        >
          <Pressable
            style={styles.modalCard}
            onPress={(e) => e.stopPropagation()}
          >
            <ThemedText type="subtitle" style={styles.modalTitle}>
              New task
            </ThemedText>

            <ThemedText style={styles.label}>Title</ThemedText>
            <TextInput
              style={styles.input}
              placeholder="Task title"
              placeholderTextColor="#94a3b8"
              value={title}
              onChangeText={setTitle}
              autoCapitalize="sentences"
            />

            <ThemedText style={styles.label}>Category</ThemedText>
            <View style={styles.chipRow}>
              {CATEGORIES.map((c) => (
                <TouchableOpacity
                  key={c.value}
                  style={[
                    styles.chip,
                    category === c.value && styles.chipActive,
                  ]}
                  onPress={() => setCategory(c.value)}
                >
                  <ThemedText
                    style={
                      category === c.value ? styles.chipTextActive : undefined
                    }
                  >
                    {c.label}
                  </ThemedText>
                </TouchableOpacity>
              ))}
            </View>

            <ThemedText style={styles.label}>Priority</ThemedText>
            <View style={styles.chipRow}>
              {PRIORITIES.map((p) => (
                <TouchableOpacity
                  key={p.value}
                  style={[
                    styles.chip,
                    priority === p.value && styles.chipActive,
                  ]}
                  onPress={() => setPriority(p.value)}
                >
                  <ThemedText
                    style={
                      priority === p.value ? styles.chipTextActive : undefined
                    }
                  >
                    {p.label}
                  </ThemedText>
                </TouchableOpacity>
              ))}
            </View>

            <ThemedText style={styles.label}>Due date (YYYY-MM-DD)</ThemedText>
            <TextInput
              style={styles.input}
              placeholder="2025-02-25"
              placeholderTextColor="#94a3b8"
              value={dueDate}
              onChangeText={setDueDate}
            />

            <View style={styles.modalActions}>
              <TouchableOpacity
                style={styles.cancelBtn}
                onPress={() => setModalVisible(false)}
              >
                <ThemedText>Cancel</ThemedText>
              </TouchableOpacity>
              <TouchableOpacity style={styles.addBtn} onPress={handleAdd}>
                <ThemedText style={styles.addBtnText}>Add</ThemedText>
              </TouchableOpacity>
            </View>
          </Pressable>
        </Pressable>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f0f2f5' },
  scroll: { flex: 1 },
  content: { padding: 16, paddingBottom: 88 },
  taskRow: { flexDirection: 'row', alignItems: 'center' },
  checkWrap: { marginRight: 12 },
  taskBody: { flex: 1 },
  taskTitle: { fontSize: 16, fontWeight: '600' },
  completed: { textDecorationLine: 'line-through', opacity: 0.7 },
  meta: { fontSize: 13, opacity: 0.8, marginTop: 4 },
  empty: { textAlign: 'center', opacity: 0.8 },
  fab: { position: 'absolute', right: 20, bottom: 24 },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.4)',
    justifyContent: 'flex-end',
  },
  modalCard: {
    backgroundColor: '#fff',
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    padding: 24,
    paddingBottom: 40,
  },
  modalTitle: { marginBottom: 16, color: '#1a1a2e' },
  label: { marginTop: 12, marginBottom: 6, fontSize: 14, fontWeight: '600' },
  input: {
    borderWidth: 1,
    borderColor: '#e2e8f0',
    borderRadius: 12,
    padding: 12,
    fontSize: 16,
    color: '#1a1a2e',
  },
  chipRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  chip: {
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: 20,
    backgroundColor: '#e2e8f0',
  },
  chipActive: { backgroundColor: Colors.light.tint },
  chipTextActive: { color: '#fff' },
  modalActions: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
    gap: 12,
    marginTop: 24,
  },
  cancelBtn: { padding: 12 },
  addBtn: {
    backgroundColor: Colors.light.tint,
    paddingHorizontal: 20,
    paddingVertical: 12,
    borderRadius: 12,
  },
  addBtnText: { color: '#fff', fontWeight: '600' },
});
