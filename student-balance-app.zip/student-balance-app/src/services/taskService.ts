/**
 * Tasks: list, add, toggleComplete. Persisted via AsyncStorage.
 */

import type { Task, TaskCategory, Priority } from '../types';
import { KEYS } from '../storage/keys';
import { getStored, setStored } from '../storage/storage';

export async function listTasks(): Promise<Task[]> {
  const tasks = await getStored<Task[]>(KEYS.TASKS);
  return tasks ?? [];
}

export async function addTask(
  title: string,
  category: TaskCategory,
  dueDate: string,
  priority: Priority
): Promise<Task> {
  const tasks = await listTasks();
  const task: Task = {
    id: `task_${Date.now()}_${Math.random().toString(36).slice(2, 9)}`,
    title,
    category,
    dueDate,
    priority,
    completed: false,
    createdAt: new Date().toISOString(),
  };
  tasks.push(task);
  await setStored(KEYS.TASKS, tasks);
  return task;
}

export async function toggleTaskComplete(id: string): Promise<void> {
  const tasks = await listTasks();
  const idx = tasks.findIndex((t) => t.id === id);
  if (idx === -1) return;
  tasks[idx].completed = !tasks[idx].completed;
  await setStored(KEYS.TASKS, tasks);
}
