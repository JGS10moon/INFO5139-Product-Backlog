/**
 * Goals: add, list, increment/decrement progress this week.
 * Persisted via AsyncStorage; works offline.
 */

import { KEYS, getStored, setStored } from './storage';
import type { Goal } from '@/types';

export async function listGoals(): Promise<Goal[]> {
  const goals = await getStored<Goal[]>(KEYS.GOALS);
  return goals ?? [];
}

export async function addGoal(title: string, targetPerWeek: number): Promise<Goal> {
  const goals = await listGoals();
  const goal: Goal = {
    id: `goal_${Date.now()}_${Math.random().toString(36).slice(2, 9)}`,
    title,
    targetPerWeek,
    progressThisWeek: 0,
    createdAt: new Date().toISOString(),
  };
  goals.push(goal);
  await setStored(KEYS.GOALS, goals);
  return goal;
}

export async function incrementGoalProgress(id: string): Promise<void> {
  const goals = await listGoals();
  const idx = goals.findIndex((g) => g.id === id);
  if (idx === -1) return;
  goals[idx].progressThisWeek += 1;
  await setStored(KEYS.GOALS, goals);
}

export async function decrementGoalProgress(id: string): Promise<void> {
  const goals = await listGoals();
  const idx = goals.findIndex((g) => g.id === id);
  if (idx === -1) return;
  goals[idx].progressThisWeek = Math.max(0, goals[idx].progressThisWeek - 1);
  await setStored(KEYS.GOALS, goals);
}

export async function setGoals(goals: Goal[]): Promise<void> {
  await setStored(KEYS.GOALS, goals);
}
